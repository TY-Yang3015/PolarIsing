# -*- coding: utf-8 -*-

from .Metropolis import Metropolis
from .Wolff import Wolff
from .Simulated_annealing import Simulated_annealing
import numpy as np


class Simulator:
    def __init__(self, algorithm, backend, inputs):
        self.algorithm = algorithm
        self.backend = backend
        self.inputs = inputs

    def _core(self, lattice):
        if self.backend == 'python':
            if self.algorithm not in ['metropolis', 'wolff', 'sa']:
                raise ValueError("Invalid algorithm choice. Please choose one among 'metropolis', 'wolff', or 'sa'.")

        elif self.backend == 'NN':
            self._run_NN(self.inputs)
            return lattice

        else:
            raise ValueError("Invalid backend choice. Please choose between 'python' or 'NN'.")


        if self.algorithm == 'metropolis':
            progress_bar = False
            field = False
            if len(self.inputs) < 2:
                raise ValueError("Invalid inputs for metropolis algorithm. Expected (temperature, iteration_step).")
            elif len(self.inputs) == 2: pass
            elif len(self.inputs) == 3:
                if isinstance(self.inputs[2], bool):
                    progress_bar = self.inputs[2]
                elif isinstance(self.inputs[2], np.ndarray):
                    field = self.inputs[2]
                else: raise ValueError('The input should be in the order (temperature, iteration_step, field, progress_bar)')
                
            elif len(self.inputs) == 4:
                progress_bar = self.inputs[3]
                field = self.inputs[2]
                if isinstance(progress_bar, bool) != True:
                    raise ValueError('The input should be in the order (temperature, iteration_step, field, progress_bar)')
                
            else: raise ValueError('Invalid Input')
            metropolis = Metropolis()
            return metropolis.execute(lattice, self.inputs[0], self.inputs[1], field=field, progress_bar=progress_bar)

        elif self.algorithm == 'wolff':
            progress_bar = False
            field = False
            if len(self.inputs) < 2:
                raise ValueError("Invalid inputs for wolff algorithm. Expected (temperature, iteration_step).")
            elif len(self.inputs) == 2: pass
            elif len(self.inputs) == 3:
                if isinstance(self.inputs[2], bool):
                    progress_bar = self.inputs[2]
                elif isinstance(self.inputs[2], np.ndarray):
                    field = self.inputs[2]
                else: raise ValueError('The input should be in the order (temperature, iteration_step, field, progress_bar)')
                
            elif len(self.inputs) == 4:
                progress_bar = self.inputs[3]
                field = self.inputs[2]
                if isinstance(progress_bar, bool) != True:
                    raise ValueError('The input should be in the order (temperature, iteration_step, field, progress_bar)')
                
            else: raise ValueError('Invalid Input')
            wolff = Wolff()
            return wolff.execute(lattice, self.inputs[0], self.inputs[1], field=field, progress_bar=progress_bar)

        elif self.algorithm == 'sa':
            progress_bar = False
            field = False
            if len(self.inputs) < 4:
                raise ValueError("Invalid inputs for simulated annealing algorithm. Expected (tf, ti, _type, iteration_step)")
            elif len(self.inputs) == 4: pass
            elif len(self.inputs) == 5:
                if isinstance(self.inputs[4], bool):
                    progress_bar = self.inputs[4]
                elif isinstance(self.inputs[4], np.ndarray):
                    field = self.inputs[4]
                else: raise ValueError('The input should be in the order (tf, ti, _type, iteration_step, field, progress_bar)')

            elif len(self.inputs) == 6:
                progress_bar = self.inputs[5]
                field = self.inputs[4]
                if isinstance(progress_bar, bool) != True:
                    raise ValueError('The input should be in the order (tf, ti, _type, iteration_step, field, progress_bar)')
                
            else: raise ValueError('Invalid Input')

            simulated_annealing = Simulated_annealing()
            return simulated_annealing.execute(lattice, *self.inputs)
        
        
    def run(self, ising_model_object):
        if ising_model_object.lattice is None:
            raise ValueError("Please create the lattice before running the simulation.")

        if self.backend == 'python':
            return self._core(ising_model_object.lattice)

        elif self.backend == 'NN':
            self._core(ising_model_object.lattice)
            return ising_model_object.lattice

        else:
            raise ValueError("Invalid backend choice. Please choose between 'python' or 'NN'.")

    def _run_NN(self, inputs):
        pass  # placeholder for NN 