# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
from tqdm.notebook import tqdm

class Analyser:
    def get_statistics(self, data):
        mean = np.mean(data)
        std = np.std(data)
        return mean, std

    def visualise_series(self, data, label):
        plt.plot(data)
        plt.xlabel("Iteration Step")
        plt.ylabel(label)
        plt.title(f"{label} vs. Iteration Step")
        plt.show()

    def visualise_lattice(self, lattice):
        plt.imshow(lattice, cmap='viridis')
        plt.colorbar()
        plt.title("Ising Model Lattice")
        plt.show()

    def get_autocorrelation(self, series, backend='fft'):
        if backend == 'fft':
            lags = np.arange(0, len(series), 1)
            n = len(series)
            ext_size = 2 * n - 1
            fsize = 2 ** np.ceil(np.log2(ext_size)).astype('int')

            xp = series - np.mean(series)
            var = np.var(series)

            cf = np.fft.fft(xp, fsize)
            sf = cf.conjugate() * cf
            corr = np.fft.ifft(sf).real
            corr = corr / var / n

            return corr[:len(lags)]

        elif backend == 'manual':
            max_lag = len(series)

            n = len(series)
            mean = np.mean(series)
            time_series = np.asarray(series)

            pbar = tqdm(range(len(time_series) + 1))

            def autocorr_for_one(lag, pbar):
                num = np.sum((time_series[:n - lag] - mean) * (time_series[lag:] - mean))
                den = np.sum((time_series - mean) ** 2)
                pbar.update(1)
                return num / den

            return np.array([autocorr_for_one(lag, pbar) for lag in range(max_lag + 1)])

        else:
            raise ValueError("Unsupported autocorrelation backend. Please choose between 'fft' and 'manual'.")