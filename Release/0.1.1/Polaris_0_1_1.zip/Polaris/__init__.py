# -*- coding: utf-8 -*-

from .Ising_model import Ising_model