# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
from .Analyser import Analyser
from .Simulator import Simulator

class Ising_model:
    def __init__(self):
        self.lattice = None
        self.energy_list = None
        self.magnetisation_list = None
        self.autocorrelation_series = None

    def create_lattice(self, size, random_initialise=True):
        self.size = size
        if random_initialise == True:
            self.lattice = np.random.choice([-1, 1], size=(size, size))
        else: self.lattice = np.ones(size=(size, size))
        return self.lattice

    def simulate(self, algorithm, backend, inputs):
        sim = Simulator(algorithm, backend, inputs)

        if backend == 'python':
            self.energy_list, self.magnetisation_list, self.lattice = sim.run(self)
            return self.energy_list, self.magnetisation_list, self.lattice

        elif backend == 'NN':
            self.lattice = sim.run(self)
            return self.lattice

    def show_results(self, autocorrelation='fft'):
        ana = Analyser()
        ana.visualise_lattice(self.lattice)
        ana.visualise_series(self.energy_list, "Energy")
        ana.visualise_series(self.magnetisation_list, "Magnetisation")
        if autocorrelation != False:
            autocorr_m = ana.get_autocorrelation(self.magnetisation_list, backend=autocorrelation)
            autocorr_e = ana.get_autocorrelation(self.energy_list, backend=autocorrelation)
            fig, ax = plt.subplots()
            ax.plot(autocorr_m, 'r-', label='magnetisation')
            ax.plot(autocorr_e, 'b-', label='energy')
            ax.legend()
            ax.set_ylabel('Autocorrelation')
            ax.set_xlabel('Lag')