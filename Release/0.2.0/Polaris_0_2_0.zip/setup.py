# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='Polaris',
    version='0.2.0',
    packages=find_packages(),
)